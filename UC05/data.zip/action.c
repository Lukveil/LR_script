Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_cookie("boomq_auth="
		"eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc19ub3RpZmljYXRlZCI6ZmFsc2UsInVzZXJfaWQiOjE4NzYsInVzZXJfbmFtZSI6Im9sb2xva3puQGdtYWlsLmNvbSIsInNjb3BlIjpbInRydXN0IiwicmVhZCIsIndyaXRlIl0sInVzZXJfbGFuZ3VhZ2UiOiJSVSIsImV4cCI6MTcyNDk3NDYwNywiYXV0aG9yaXRpZXMiOlsiUk9MRV9VU0VSIl0sImp0aSI6ImY4NmZiNWQ2LTFjNjUtNDM4Yi1iNzVlLTIxMzMzNDI2ZmYzNiIsImNsaWVudF9pZCI6ImNsaWVudCJ9.IlGWNLb4RMwrh9zMeHLs28kiUJdI9oiIZ5_guKb4ubcjV5hl23hUZHCJoUEmFWDJ9XlJVFpPPDUcm0nfr0jxA8MBAQsIul1H5fulvL7H7NUZk7FL80440x9FLe6TZJz82Vj640XuUqMxi0hkJh19"
		"fbNacoys_wI1wnMJl0d1HgtjDf4QZE839wbSFucBxWHUOvFRQfHXcgnpKXXIRAScZ45HcfGYKFvnABax168nHrQFPEvl0X7O7l1oKIujFEM8MinZ4Zype-sSlsLtxrOVACXgeX_OR7Ake10Qt3kxGfyu3UNQsyRyTMnNcapmexTUUQAVI5dLhD_kYq8IKag7bQ; DOMAIN=dev-boomq.pflb.ru");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("sec-ch-ua", 
		"\"Chromium\";v=\"128\", \"Not;A=Brand\";v=\"24\", \"Google Chrome\";v=\"128\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("user", 
		"URL=https://dev-boomq.pflb.ru/auth-srv/user", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://dev-boomq.pflb.ru/authorize", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	/*Possible OAUTH authorization was detected. It is recommended to correlate the authorization parameters.*/

	web_url("identityProvider", 
		"URL=https://dev-boomq.pflb.ru/auth-srv/identityProvider", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://dev-boomq.pflb.ru/authorize", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	web_url("modelSchema", 
		"URL=https://dev-boomq.pflb.ru/project-srv/modelSchema", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://dev-boomq.pflb.ru/account/new-test", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	web_url("14", 
		"URL=https://dev-boomq.pflb.ru/auth-srv/team/14", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://dev-boomq.pflb.ru/authorize", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("boomq_auth="
		"eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc19ub3RpZmljYXRlZCI6ZmFsc2UsInVzZXJfaWQiOjE4NzYsInVzZXJfbmFtZSI6Im9sb2xva3puQGdtYWlsLmNvbSIsInNjb3BlIjpbInRydXN0IiwicmVhZCIsIndyaXRlIl0sInRlYW1fbWVtYmVyIjoie1wiaWRcIjoxOTU1LFwidGVhbUlkXCI6MTQsXCJ1c2VySWRcIjoxODc2LFwiZW1haWxcIjpcIm9sb2xva3puQGdtYWlsLmNvbVwiLFwidXNlckRpc3BsYXlOYW1lXCI6XCJUaW11clwiLFwicGVybWlzc2lvbkxpc3RcIjpbXCJSVU5cIixcIlZJRVdcIixcIkVESVRcIixcIkFETUlOXCIsXCJNQU5BR0VfVVNFUlNfSU5fT1JHXCJdLFwiaW52aXRhdGlvblN0YXR1c1wiOlwiQUNDRVBURURcIixcImludml0Z"
		"VVybFwiOm51bGwsXCJleHBpcmVkQXRcIjpudWxsLFwiY3JlYXRlQXRcIjpcIjIwMjQtMDgtMTlUMTM6MjU6MjguODA1WlwiLFwidXBkYXRlZEF0XCI6XCIyMDI0LTA4LTE5VDEzOjI1OjM2LjIyMlpcIn0iLCJ1c2VyX2xhbmd1YWdlIjoiUlUiLCJ0ZWFtX2lkIjoxNCwiZXhwIjoxNzI0OTc0NjA3LCJhdXRob3JpdGllcyI6WyJST0xFX1VTRVIiXSwianRpIjoiMTkyMjc5YzktMjYwZS00ZjQ3LTk3OWYtMzZhNzZiY2Y1YTRmIiwiY2xpZW50X2lkIjoiY2xpZW50In0.sbZYFa-lVDu0XL0zx6BRoxKoQdFtK_42LaQ445bTVSauQsccrNUE8--35RGe9K0vgswMNt-jqrN0KxOR6V8twJonDlVxRFIfhj1xfRq6RFwLVvlvnPyvhDpEDVosCx4khaX2F7kJtDHKfl3H5q0pG3n"
		"LBIILAtzuHcZA0ON-wInV13k3Kr2M-MvOM_uImF9idVnzJZ6qA9YXu4rfjbx7-gBiQwO8MNYtdqGrIjNteermy9FILdkOImUMkbfZaT1B7ZS-ogpY6mvrAAhee8yrXedaJ-ik-9AHCsdek_1aS_JaXtLUixPSdreQxeSlUCt6zGfpVZyb7uFdn8sPZlqI_Q; DOMAIN=dev-boomq.pflb.ru");

	web_url("teamContext", 
		"URL=https://dev-boomq.pflb.ru/auth-srv/teamMember/teamContext?teamId=14", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://dev-boomq.pflb.ru/account/new-test", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	web_url("testRunner", 
		"URL=https://dev-boomq.pflb.ru/test-runner-srv/testRunner?sort=id,desc", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://dev-boomq.pflb.ru/account/new-test", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}