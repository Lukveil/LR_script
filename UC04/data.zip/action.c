Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_cookie("boomq_auth="
		"eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc19ub3RpZmljYXRlZCI6ZmFsc2UsInVzZXJfaWQiOjE4NzYsInVzZXJfbmFtZSI6Im9sb2xva3puQGdtYWlsLmNvbSIsInNjb3BlIjpbInRydXN0IiwicmVhZCIsIndyaXRlIl0sInVzZXJfbGFuZ3VhZ2UiOiJSVSIsImV4cCI6MTcyNDk1Nzc4MCwiYXV0aG9yaXRpZXMiOlsiUk9MRV9VU0VSIl0sImp0aSI6ImFjYmMyNjljLTExNWQtNDYwOS05OGZlLWMxNDkxYWMwZDM1NiIsImNsaWVudF9pZCI6ImNsaWVudCJ9.vwKczsHvpuFexX-pU14hFyE63-bxH2pv9gNmY3-QuUIwCM4PSspzSAJM-0lnAqy5t6cQNU6w7ErCaLz0UgLK_oJpt5-2ppgGqfaJsZ7ELSDHJGSOsd9_U1wj9LIexdPqSJMegt9K0P1rzx5bkmQn"
		"ejMJxJHgMwuIsZ_0GsSsKl9-OuZxK_mHxfc4PbOVDYQP4D3uaGTk1CjL2Qb75OjolzoTrbZr6kmg-_4-ysuTOvDf85-dGh0bWmYsX-x16TRkcErFPSBkR7C1v-hSVc5itUF4Nue4zVIoOTae-m3ihre3hxm5U1VWlloOeN0kvUK4iIhSoVLmw4ptut-qy0sqbw; DOMAIN=dev-boomq.pflb.ru");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("sec-ch-ua", 
		"\"Chromium\";v=\"128\", \"Not;A=Brand\";v=\"24\", \"Google Chrome\";v=\"128\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("user", 
		"URL=https://dev-boomq.pflb.ru/auth-srv/user", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://dev-boomq.pflb.ru/authorize", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	/*Possible OAUTH authorization was detected. It is recommended to correlate the authorization parameters.*/

	web_url("identityProvider", 
		"URL=https://dev-boomq.pflb.ru/auth-srv/identityProvider", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://dev-boomq.pflb.ru/authorize", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	web_url("14", 
		"URL=https://dev-boomq.pflb.ru/auth-srv/team/14", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://dev-boomq.pflb.ru/authorize", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	web_url("modelSchema", 
		"URL=https://dev-boomq.pflb.ru/project-srv/modelSchema", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://dev-boomq.pflb.ru/account/new-test", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("boomq_auth="
		"eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc19ub3RpZmljYXRlZCI6ZmFsc2UsInVzZXJfaWQiOjE4NzYsInVzZXJfbmFtZSI6Im9sb2xva3puQGdtYWlsLmNvbSIsInNjb3BlIjpbInRydXN0IiwicmVhZCIsIndyaXRlIl0sInRlYW1fbWVtYmVyIjoie1wiaWRcIjoxOTU1LFwidGVhbUlkXCI6MTQsXCJ1c2VySWRcIjoxODc2LFwiZW1haWxcIjpcIm9sb2xva3puQGdtYWlsLmNvbVwiLFwidXNlckRpc3BsYXlOYW1lXCI6XCJUaW11clwiLFwicGVybWlzc2lvbkxpc3RcIjpbXCJSVU5cIixcIlZJRVdcIixcIkVESVRcIixcIkFETUlOXCIsXCJNQU5BR0VfVVNFUlNfSU5fT1JHXCJdLFwiaW52aXRhdGlvblN0YXR1c1wiOlwiQUNDRVBURURcIixcImludml0Z"
		"VVybFwiOm51bGwsXCJleHBpcmVkQXRcIjpudWxsLFwiY3JlYXRlQXRcIjpcIjIwMjQtMDgtMTlUMTM6MjU6MjguODA1WlwiLFwidXBkYXRlZEF0XCI6XCIyMDI0LTA4LTE5VDEzOjI1OjM2LjIyMlpcIn0iLCJ1c2VyX2xhbmd1YWdlIjoiUlUiLCJ0ZWFtX2lkIjoxNCwiZXhwIjoxNzI0OTU3NzgwLCJhdXRob3JpdGllcyI6WyJST0xFX1VTRVIiXSwianRpIjoiZWY1ZmFjY2EtODRjNi00ODA3LWJiOGUtYzk1OGJjYjRhNTM0IiwiY2xpZW50X2lkIjoiY2xpZW50In0.OHXMSiePLOFQXxe5uOpjUkh1GbBhG23Gh_aWqAbsBdI2oE3qFajdSxFDO6gu94708W9iZwxDwwQ1azDKiZFLO5F9xiWCZr8zwZbBj6bSrSmRmo2kJc3pobJw7Ovnlxg3fn7kUSCW_HqD2Tkr-CFTyxH"
		"FKnaYRRypND2G-zOC56LX6h8hQZoFfuuqVNHzk0hgcZLmm8Qur0yNL8rP5q33-5tE6nbzGqK78b6gmRQD01p9nhsAkyhttP-ICglaPh1KO7uKC71gjSXjSm8MkEVmXRbecF1FSRVevBYW7ua19mpb0X7DG01avjP2rgp57QUM7QvQJJmGfcOUzRhxWcY1VQ; DOMAIN=dev-boomq.pflb.ru");

	web_url("teamContext", 
		"URL=https://dev-boomq.pflb.ru/auth-srv/teamMember/teamContext?teamId=14", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://dev-boomq.pflb.ru/account/new-test", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	web_url("testRunner", 
		"URL=https://dev-boomq.pflb.ru/test-runner-srv/testRunner?sort=id,desc", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://dev-boomq.pflb.ru/account/new-test", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}