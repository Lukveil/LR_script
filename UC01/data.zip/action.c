Action()
{

	lr_start_transaction("sign_in");

	lr_end_transaction("sign_in",LR_AUTO);

	lr_start_transaction("chance_group");

	lr_end_transaction("chance_group",LR_AUTO);

	lr_start_transaction("create_user");

	lr_end_transaction("create_user",LR_AUTO);

	lr_start_transaction("walk_link");

	return 0;
}